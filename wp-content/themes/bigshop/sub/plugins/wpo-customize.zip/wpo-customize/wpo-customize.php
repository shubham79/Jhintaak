<?php
/**
 * Plugin Name: WPO Customize
 * Plugin URI: https://wpopal.com
 * Description: Customize theme
 * Version: 1.1.2
 * Author: Duc Pham Tien
 * Author URI: https://wpopal.com
 * License: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: wpo-customize
 * Domain Path: /languages
 *
 * @package   Widget_Importer_Exporter
 * @copyright Copyright (c) 2014, Wpopal Team
 * @link      https://wpopal.com
 * @license   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

// No direct access
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Main class
 *
 * @since 0.1
 */
class WPO_Customize {


	public function __construct() {

		// Set plugin data
		add_action( 'plugins_loaded', array( &$this, 'set_plugin_data' ), 1 );

		// Load define
		add_action( 'plugins_loaded', array( &$this, 'define_constants' ), 1 );

		if(!is_admin()){
			add_action( 'init',array($this,'initScripts') );
			add_action( 'wp_footer',array($this,'renderLiveThemeEditor') );
		}

	}

	public function initScripts(){
		wp_enqueue_style('WCTZ_customize_css', WCTZ_URL.'/assets/css/customize.css');
		wp_enqueue_style('WCTZ_colorpicker_css', WCTZ_URL.'/assets/css/colorpicker.css');
		wp_enqueue_script( 'WCTZ_colorpicker_js',WCTZ_URL.'/assets/js/colorpicker.js',array(),false,true );
		wp_enqueue_script( 'WCTZ_customize_js',WCTZ_URL.'/assets/js/customize.js',array(),false,true );
	}

	/**
	 * Define constants
	 *
	 * @since 0.1
	 * @access public
	 */
	public function define_constants() {
		define( 'WCTZ_FILE', 		__FILE__ );											// plugin's main file path
		define( 'WCTZ_DIR', 			dirname( plugin_basename( WCTZ_FILE ) ) );			// plugin's directory
		define( 'WCTZ_PATH',			untrailingslashit( plugin_dir_path( WCTZ_FILE ) ) );	// plugin's directory path
		define( 'WCTZ_URL', 			untrailingslashit( plugin_dir_url( WCTZ_FILE ) ) );	// plugin's directory URL

		define( 'WCTZ_XML_PATH', 	get_template_directory().'/sub/customize/' );
		define( 'WCTZ_STYLE_PATH', 	WCTZ_XML_PATH.'assets/' );
	}

	public function renderLiveThemeEditor(){
		$xmlselectors = $this->getXmlSelectors();
		$patterns = $this->getPattern();
		$backgroundImageURL = get_template_directory_uri().'/images/bg/';
		$files = $this->getFileCss();
		$skills = $this->getSkills();
		ob_start();
		require(WCTZ_PATH.'/tpl/editor.php');
		echo ob_get_clean();
	}


	private function getSkills(){
		$path = get_template_directory().'/css/skins/*.css';
		$files = glob($path);
		$arr = array('template.css'=>'default');
		if(count($files)>0){
			foreach ($files as $key => $file) {
				$fn = str_replace( '.css', '', basename($file) );
				$arr['skins/'.$fn.'.css']=$fn;
			}
		}
		return $arr;
	}

	/**
	 *
	 */
	public function getPattern(){
		$output = array();
		$files = glob( get_template_directory() . '/images/bg/*');
		if(isset($files) && !empty($files)){
			foreach( $files as $dir ){
				if( preg_match("#.png|.jpg|.gif#", $dir)){
					$output[] = str_replace("","",basename( $dir ) );
				}
			}
		}
		return $output;
	}

	/**
	 *
	 */
	public function getFileCss( ) {
		$output = array();
		$directories = glob( WCTZ_STYLE_PATH.'*.css');
		foreach( $directories as $dir ){
			$output[] = basename( $dir );
		}
		return $output;
	}

	/**
	 *
	 */
	public  function getXmlSelectors(){
		$customizeXML = WCTZ_XML_PATH.'themeeditor.xml';

 		$output = array( 'selectors' => array(), 'elements' => array() );

 		if( file_exists($customizeXML) ){
			$info = simplexml_load_string( file_get_contents($customizeXML) );

			if( isset($info->selectors->items) ){
				$label = $info->selectors->attributes();
				if(isset($label['label'])){
					$output['selectors']['label'] = (string) $label['label'];
				}else{
					$output['selectors']['label'] = 'Selectors';
				}
				foreach( $info->selectors->items as $item ){
					$vars = get_object_vars($item);
					if( is_object($vars['item']) ){
						$tmp = get_object_vars( $vars['item'] );
						$vars['selector'][] = $tmp;
					}else {
						foreach( $vars['item'] as $selector ){
							$tmp = get_object_vars( $selector );
							if( is_array($tmp) && !empty($tmp) ){
								$vars['selector'][] = $tmp;
							}
						}
					}
					unset( $vars['item'] );
					$output['selectors']['groups'][$vars['match']] = $vars;
				}
			}

			if( isset($info->elements->items) ){
				$label = $info->elements->attributes();
				if(isset($label['label'])){
					$output['elements']['label'] = (string) $label['label'];
				}else{
					$output['elements']['label'] = 'Elements';
				}
				foreach( $info->elements->items as $item ){
					$vars = get_object_vars($item);
					if( is_object($vars['item']) ){
						$tmp = get_object_vars( $vars['item'] );
						$vars['selector'][] = $tmp;
					}else {
						foreach( $vars['item'] as $selector ){
							$tmp = get_object_vars( $selector );
							if( is_array($tmp) && !empty($tmp) ){
								$vars['selector'][] = $tmp;
							}
						}
					}
					unset( $vars['item'] );
					$output['elements']['groups'][$vars['match']] = $vars;
				}
			}
		}
		return $output;
	}

	/**
	 * Set plugin data
	 *
	 * This data is used by constants.
	 *
	 * @since 0.1
	 * @access public
	 */
	public function set_plugin_data() {

		// Load plugin.php if get_plugins() not available
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	}

	public function l($text){
		return $text;
	}

}

// Instantiate the main class
new WPO_Customize();
