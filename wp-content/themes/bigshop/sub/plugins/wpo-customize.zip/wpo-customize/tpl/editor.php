<div id="wpo-customize-panel" class="page-wrapper hidden-sm hidden-xs">
		<div class="wpo-customize" id="wpo-customize">
			<div class="panelbutton">
				<i class="glyphicon glyphicon-adjust"></i>
			</div>
			<div class="wrapper">
				<div id="customize-form">
					<div class="group-input">
						<label>Skins</label>
						<select name="wpo-skill" id="wpo-customize-skill">
							<?php foreach ($skills as $key => $skill) {
								echo '<option value="'.$key.'">'.$skill.'</option>';
							} ?>
						</select>
					</div>
					<!-- TAB INPUT -->
					<div class="clearfix" id="customize-body">
						<!-- TAB TITLE -->
						<ul class="nav nav-tabs" id="myTab">
						<?php $i=0; ?>
						<?php foreach( $xmlselectors as $for => $output ) { ?>
						    <li <?php if($i==0) echo 'class="active"'; ?>>
						    	<a data-toggle="tab" href="#tab-<?php echo $for ?>">
						    		<?php echo $this->l( $output['label'] );?>
						    	</a>
						    </li>
					    <?php
						    	$i++;
						    }// End foreach
					    ?>
						</ul>
						<!-- END TAB TITLE -->

						<!-- TAB CONTENT -->
						<div class="tab-content" >
						<?php $i=0; ?>
						<?php foreach( $xmlselectors as $for => $output ) { //var_dump($output);die;?>
							<div class="tab-pane <?php if($i==0) echo 'active'; ?>" id="tab-<?php echo $for; ?>">
								<?php if( !empty( $output ) ){?>
								<!-- ACCORDION -->
								<div class="accordion panel-group"  id="custom-accordion<?php echo $for; ?>">
									<?php $i=0; foreach ( $output['groups'] as $group ) { ?>
										<div class="accordion-group panel panel-default">
											<div 	class="accordion-heading panel-heading"
													data-toggle="collapse"
													data-parent="#custom-accordion<?php echo $for; ?>"
													href="#collapse<?php echo $group['match'];?>" >
												<a class="accordion-toggle">
		                               				<?php echo $group['header']; ?>
			                              		</a>
			                              	</div>
		                              		<!-- ACCORDION ITEM CONTENT -->
											<div id="collapse<?php echo $group['match'];?>"
													class="accordion-body panel-collapse collapse <?php if( $i++ ==0) { ?> in <?php } ?>">
												<div class="accordion-inner panel-body clearfix">
													<?php foreach ($group['selector'] as $item ) { ?>

													<?php  if (isset($item['type'])&&$item['type']=="image") { ?>
														<div class="form-group background-images">
															<label><?php echo $item['label']?></label>
															<a class="clear-bg label label-success" href="#">
																<i class="fa fa-ban"></i>
															</a>
															<input value="" type="hidden" name="customize[<?php echo $group['match'];?>][]" data-match="<?php echo $group['match'];?>" class="input-setting" data-selector="<?php echo $item['selector']?>" data-attrs="background-image">
															<div class="clearfix"></div>
															<p>
																<em style="font-size:10px"><?php echo $this->l('Those Images in folder YOURTHEME/images/bg/') ?></em>
															</p>
															<div class="bi-wrapper clearfix">
																<?php foreach ( $patterns as $pattern ){ ?>
																<div style="background:url('<?php echo $backgroundImageURL.$pattern;?>') no-repeat center center;" class="pull-left" data-image="<?php echo $backgroundImageURL.$pattern;?>" data-val="../../../images/bg/<?php echo $pattern; ?>">

																</div>
																<?php } ?>
															</div>
														</div>
													<?php } elseif( $item['type'] == "fontsize" ) { ?>
														<div class="form-group">
															<label><?php echo $item['label']?></label>
															<select name="customize[<?php echo $group['match'];?>][]" data-match="<?php echo $group['match']?>" type="text" class="input-setting enable" data-selector="<?php echo $item['selector']?>" data-attrs="<?php echo $item['attrs']?>">
																<option value="">Inherit</option>
																<?php for( $i=9; $i<=16; $i++ ) { ?>
																<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
																<?php } ?>
															</select>
															<a href="#" class="clear-bg label label-success"><i class="fa fa-ban"></i></a>
														</div>
													<?php } else { ?>
														<div class="form-group">
															<label><?php echo $item['label']?></label>
															<input value="" size="10" name="customize[<?php echo $group['match']?>][]" data-match="<?php echo $group['match']?>" type="text" class="input-setting enable" data-selector="<?php echo $item['selector']?>" data-attrs="<?php echo $item['attrs']?>">
															<a href="#" class="clear-bg label label-success"><i class="fa fa-ban"></i></a>
														</div>
													<?php } ?>


													<?php }//end foreach ?>
												</div>
											</div>
											<!-- END ACCORDION ITEM CONTENT -->
										</div>
									<?php } ?>
								</div>
								<!-- END ACCORDION -->
								<?php }//end if ?>
							</div>
						<?php $i++; ?>
						<?php }// end if ?>
						</div>
						<!-- END TAB CONTENT -->
					</div>
					<!-- END TAB INPUT -->
				</div>
			</div>
		</div>
	<script>
	jQuery(document).ready(function() {
		jQuery('body').WPO_ThemeCustomize({
			customizeURL:'<?php echo FRAMEWORK_CUSTOMZIME_STYLE_URI; ?>',
			templateURL:'<?php echo get_template_directory_uri(); ?>'
		});
	});
	</script>
</div>

