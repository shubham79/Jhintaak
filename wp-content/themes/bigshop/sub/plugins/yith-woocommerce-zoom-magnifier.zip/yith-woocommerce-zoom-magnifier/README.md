YITH WooCommerce Zoom Magnifier
==============

YITH WooCommerce Zoom Magnifier is Wordpress plugins that enables you to add a zoom effect to product images. It requires WooCommerce.

Offer to your visitors a chance to inspect in detail the quality of your products. With YITH WooCommerce Zoom Magnifier you can add a zoom effect to all your product images.
The Wordpress plugin also adds a slider below the featured image with your product gallery images.

Working demo are available:

**[LIVE DEMO 1](http://demo.yithemes.com/room09/product/africa-style/)** - **[LIVE DEMO 2](http://demo.yithemes.com/bazar/shop/ankle-shoes/)**


Full documentation is available [here](http://yithemes.com/docs-plugins/yith_magnifier/).